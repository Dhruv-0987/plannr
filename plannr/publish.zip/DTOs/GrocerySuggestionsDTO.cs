﻿using System;
namespace plannr.DTOs
{
	public class GrocerySuggestionsDTO
	{
        public double WeeklyBudget { get; set; }
        public int FamilySize { get; set; }
        public GrocerySuggestionsDTO()
		{
		}
	}
}

